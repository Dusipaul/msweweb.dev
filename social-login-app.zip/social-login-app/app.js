// Load environment variables
require("dotenv").config();

// Import required modules
const express = require("express");
const passport = require("passport");
const session = require("express-session");
const GoogleStrategy = require("passport-google-oauth20").Strategy;

// Initialize Express app
const app = express();

// Session configuration
app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: true,
  }),
);

// Initialize Passport
app.use(passport.initialize());
app.use(passport.session());

// Passport Google Strategy
passport.use(
  new GoogleStrategy(
    {
      clientID: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      callbackURL: process.env.GOOGLE_CALLBACK_URL,
    },
    (accessToken, refreshToken, profile, done) => {
      return done(null, profile);
    },
  ),
);

// Serialize and deserialize user
passport.serializeUser((user, done) => {
  done(null, user);
});

passport.deserializeUser((user, done) => {
  done(null, user);
});

// Routes
app.get("/", (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Login</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
      <style>
        body {
          background: linear-gradient(135deg, #667eea, #764ba2);
          height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #fff;
        }
        .card {
          background: rgba(255, 255, 255, 0.1);
          border: none;
          border-radius: 15px;
          backdrop-filter: blur(10px);
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }
        .btn-social {
          width: 100%;
          margin-bottom: 10px;
          color: #fff;
          border: none;
        }
        .btn-google {
          background: #db4437;
        }
        .btn-google:hover {
          opacity: 0.9;
          color: #fff;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-6">
            <div class="card text-center p-4">
              <h1 class="card-title mb-4">Welcome</h1>
              <p class="card-text mb-4">Please log in to continue.</p>
              <a href="/auth/google" class="btn btn-social btn-google">Login with Google</a>
            </div>
          </div>
        </div>
      </div>
    </body>
    </html>
  `);
});

// Google authentication route
app.get(
  "/auth/google",
  passport.authenticate("google", { scope: ["profile", "email"] }),
);

// Google callback route
app.get(
  "/auth/google/callback",
  passport.authenticate("google", { failureRedirect: "/" }),
  (req, res) => {
    res.redirect("/profile");
  },
);

// Profile route
app.get("/profile", (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect("/");
  }

  const user = req.user;
  const profilePicture = user._json.picture || "/default-profile-picture.jpg";

  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Profile</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
      <style>
        body {
          background: linear-gradient(135deg, #667eea, #764ba2);
          height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #fff;
        }
        .card {
          background: rgba(255, 255, 255, 0.1);
          border: none;
          border-radius: 25px;
          backdrop-filter: blur(10px);
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
          padding: 40px 30px;
        }
        .profile-picture {
          width: 150px;
          height: 150px;
          border-radius: 50%;
          margin-bottom: 20px;
          object-fit: cover;
          border: 5px solid #fff;
        }
        .btn-logout {
          background: #ff4d4d;
          color: #fff;
          border: none;
          border-radius: 20px;
          padding: 10px 20px;
        }
        .btn-logout:hover {
          opacity: 0.9;
        }
        h1 {
          font-size: 3rem;
          color: #fff;
          margin-bottom: 20px;
        }
        .card-text {
          font-size: 1.2rem;
          color: #fff;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-6">
            <div class="card text-center">
              <img src="${profilePicture}" alt="Profile Picture" class="profile-picture">
              <h1>Welcome, ${user.displayName}</h1>
              <p class="card-text"><strong>Name:</strong> ${user.displayName}</p>
              <p class="card-text"><strong>Email:</strong> ${user._json.email || "Not provided"}</p>
              <a href="/logout" class="btn btn-logout">Logout</a>
            </div>
          </div>
        </div>
      </div>
    </body>
    </html>
  `);
});

// Logout route
app.get("/logout", (req, res) => {
  req.logout((err) => {
    if (err) {
      return res.status(500).send("Error logging out");
    }
    res.redirect("/");
  });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
